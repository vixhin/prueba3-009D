import tiendecita
print("Bienvenido a MUNDO LIBRO")
print("  ")

while True:
    print("*******************************************************************************************************")
    print("********************************************MUNDO LIBRO************************************************")
    print("*******************************************************************************************************")
    print("1. Matenedor de categorías.")
    print("2. Reportes.")
    print("3. Salir")
    respuesta = input("Ingrese a sección que desea acceder: ")
    
    if respuesta == "1":
        print("                 Mantenedor categorías")
        print("1. Agregar categoría.")
        print("2. Editar categoría.")
        print("3. Eliminar categoría.")
        print("4. Buscar categoría.")
        print("5. Volver")
        opcion = input("Ingrese su opción: ")
        if opcion == "1":
            tiendecita.agregar_categoria()
        elif opcion == "2":
            tiendecita.editar_categoria()
        elif opcion == "3":
            tiendecita.eliminar_categoria()
        elif opcion == "4":
            tiendecita.buscar_categoria()
        elif opcion == "5":

            break
        else:
            print("opcion incorrecta.")
    elif respuesta == "2":
        tiendecita.abrir_reportes()
