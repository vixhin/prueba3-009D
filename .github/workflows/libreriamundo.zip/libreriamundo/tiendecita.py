import json
def cargardatos():
    with open("biblioteca.json","r") as archivo:
        leerJson = json.load(archivo)
        return leerJson

def agregar_categoria():
    datos = cargardatos()
    contador = 12
    nombre = input("Ingrese el nombre de su nueva categoría: ")
    for i in datos["Categoria"]:
        CategoriaID = contador+1
        nueva_categoria ={
            "CategoriaID": CategoriaID,
            "Nombre": nombre
        }
    datos["Categoria"].append(nueva_categoria)
    contador += 1
        
def abrir_reportes():
    with open("Reportes_biblioteca_mundo_libro.json", "r") as archivo:
        datos = json.load(archivo)
        print("Nombre Libro                             Prestamos")
        print("  ")
        for i in datos["prestamos"]:
            print(i["nombre_libro"]                              ,i["veces_prestado"],indent=6)

def editar_categoria(id:int,nombre:str):
    datos = cargardatos
    id = input("Ingrese el id de la Categoria que cambiara: ")
    contador = 0
    for i in datos["Categoria"]:
        if i["CategoriaID"] == id:
            contador +=1
            nombre = input("Ingrese el nuevo nombre de la categoria: ")
            datos["Categoria"][contador]["CategoriaID"] = id
            datos["Categoria"][contador]["Nombre"] = nombre
def eliminar_categoria():
    datos = cargardatos

def buscar_categoria():
    datos = cargardatos()
    for i in datos:
        print(i,   i[datos["Autor"]])
        print(i,   i[datos["Categoria"]])
        print(i,   i[datos["Libro"]])
        print(i,   i[datos["Usuarios"]])
        print(i,   i[datos["Prestamo"]])
